const CACHE="desafio-logico-shell-v21";
// Pacote mobile atualizado em 20/11/2026.
const ASSETS=["./","./index.html","./style.css","./app.js","./phase-data.js","./ads-test.js","./manifest.webmanifest","./icons/app-icon.svg","./data/phases.json"];
self.addEventListener("install",event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS))));
self.addEventListener("activate",event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key))))));
self.addEventListener("fetch",event=>{if(event.request.method!=="GET")return;event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request).then(response=>{const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(event.request,copy));return response}).catch(()=>caches.match("./index.html"))))});