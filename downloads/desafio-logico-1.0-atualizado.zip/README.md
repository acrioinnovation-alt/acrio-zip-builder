# Desafio Lógico 1.0 — ACRIO GAMES

Repositório oficial: `acrioinnovation-alt/desafio-logico1.0`.

## Fluxo
- Jornada única e sequencial, sem seleção de família, nível ou fase.
- As cinco famílias aparecem misturadas.
- Progressão de dificuldade: Fácil, Médio, Difícil e Especialista.
- Progresso salvo localmente no navegador.

## Famílias
1. Palitos de fósforo — desafio visual com palitos que o jogador toca para retirar.
2. Balanças e pesos — três balanças ilustradas com pistas combinadas; o jogador cruza as igualdades para deduzir o peso de um animal ou objeto.
3. Equações com figuras.
4. Recipientes e quantidades.
5. Código secreto.

## Estado real do conteúdo
O protótipo reserva 200 posições (40 por família), mas os desafios ainda são gerados por regras. Isso **não significa que existam 200 enigmas exclusivos, revisados e validados**. As outras quatro famílias ainda precisam de mecânicas visuais mais completas e os 200 desafios precisam ser escritos e testados individualmente.

## Execução
Abra `index.html` em um navegador moderno. Não exige Node.js ou npm.



## Ilustrações — Balanças e Pesos

As balanças e os animais são desenhados por SVG diretamente no `app.js`, com estilos no `styles.css`. Não dependem de fotografias, arquivos externos, CDN ou conexão com a internet. As formas são ilustrações vetoriais estilizadas, com gradientes e sombras, incorporadas ao próprio código.
